Exact burn-progression editing queries

Extract all files and run python verify.py (Python 3.10+ standard library).
The verifier recomputes eligibility and every integer opacity crossing from native events and fixed camera weights.
It checks each warmup and timed reply, checks the retained full progression curves, reconstructs the requested
light-first decision, verifies short-circuit behavior, and prints directly comparable per-method median milliseconds.
L denotes a light stroke, F the full stroke. The 90-step cases compare both from a common first stroke and identical
initial target. The 180-step development cases use different first strokes. An event-free deadline is retained.
One unit of static weight is one millionth of a pixel-equivalent of front-to-back foreground opacity.
Single-candidate and complete-action sessions have different clocks. Action calls include restoring the initial parent
and can share one physical evolution across two camera readouts. Equivalence calls can infer the other result
from a single physical trajectory when its entire observed exterior is certified equal. The original held-out
physical-precheck session with a clock error in its independent auditing wrapper is excluded. Its failed
receipt and the corrected native-step audit are preserved separately in the research repository.
Eight source-image-free histograms record final native RGB contrast against drawing the same wood without gas.
The verifier reconstructs the fixed display cutoff, target mass and two light-first camera choices from the bins.
The T129 record, t129-native-image-choice.json.gz, contains 56 delivered native image decisions (48 measured and
8 warmups). Its two processes report each method's per-action and phase times, short-circuited views, cold setup,
the independent endpoint and PNG audit, and the original timing index. These calls reuse the known woodpile and the
same comparison from the eight paired display observations. The 912 material decisions use material onset records.
Each session records its own excluded warmup and number of measured rotations on one host. Camera construction and shot loading
are separate. Full-precision 3D geometry is externally sourced. This bundle verifies event observations and latency
aggregation, not raster construction, native particle dynamics or independent performance reproduction.
