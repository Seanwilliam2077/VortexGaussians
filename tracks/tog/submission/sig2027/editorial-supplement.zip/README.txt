Exact burn-progression editing queries

Extract all files and run python verify.py (Python 3.10+ standard library).
The verifier recomputes eligibility and every integer opacity crossing from native events and fixed camera weights.
It checks each warmup and timed reply, checks the retained full progression curves, reconstructs the requested
light-first decision, verifies short-circuit behavior, and prints directly comparable per-method median milliseconds.
L denotes a light stroke, F the full stroke. The 90-step cases compare both from a common first stroke and identical
initial target. The 180-step development cases use different first strokes. An event-free deadline is retained.
One unit of static weight is one millionth of a pixel-equivalent of front-to-back foreground opacity.
Single-candidate and complete-action sessions have different clocks. Action calls include restoring the initial parent
and can share one physical evolution across two camera readouts; they return a choice, not a kept simulation.
Each session records its own excluded warmup and number of measured rotations on one host. Camera construction and shot loading
are separate. Full-precision 3D geometry is externally sourced. This bundle verifies event observations and latency
aggregation, not raster construction, native particle dynamics or independent performance reproduction.
