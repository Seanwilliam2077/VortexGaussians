"""Rebuild the thermal masks and compare the public calculations to the frozen scores."""
import gzip
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
T86 = ROOT / "t86-ignition-margin"
sys.dont_write_bytecode = True


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == ".gz" else data)


def check(condition, message):
    if not condition:
        raise ValueError(message)


def up(initial, addition, writes):
    return (initial + addition * (1 + 1e-11) + writes * 2.0**-126) / (1 - writes * 2.0**-24)


def verify_thermal():
    saved = read(T86 / "PREDICTIONS.json.gz")
    by_cut = {(q["arm"], q["cut"], q["horizon"]): q for q in saved["queries"]}
    checks = 0
    for arm in ("AB", "BA"):
        for cut in (210, 240, 300):
            state = read(T86 / "public" / f"{arm}-{cut}-eligibility.json.gz")
            x = read(ROOT / "thermal-inputs" / f"{arm}-{cut}.json.gz")
            ids = [i for i, (s, f) in enumerate(zip(state["state"], state["fuel"])) if s == 0 and f > 0]
            check((x["arm"], x["cut"]) == (arm, cut) and len(x["steps"]) == 8, "input identity")
            check(len(x["graph"]) == len(x["graph_writes"]) == len(ids), "graph shape")
            for method in saved["methods"]:
                heat = [state["heat"][i] for i in ids]
                safe = [True] * len(ids)
                for k, step in enumerate(x["steps"], start=1):
                    check(len(step["count"]) == len(step["weighted"]) == len(ids), "gas shape")
                    for j, count in enumerate(step["count"]):
                        writes = x["cap"] if method == "global" else count
                        if method == "weighted":
                            factor = step["weighted"][j]
                        elif method == "support" and count:
                            factor = x["cap"]
                            safe[j] = False
                        else:
                            factor = writes
                        before = up(heat[j], factor * (x["dt"] * x["rate"]), writes)
                        scan = up(0, before * (1 - x["dt"] * .35), 1)
                        safe[j] = safe[j] and scan < x["threshold"]
                        heat[j] = up(scan, x["graph"][j], x["graph_writes"][j])
                    if k in (1, 4, 8):
                        result = [i for i, safe_here in zip(ids, safe) if safe_here]
                        check(result == by_cut[arm, cut, k]["certified"][method], "thermal mask mismatch")
                        checks += 1
    print(f"Rebuilt {checks} exact site-ID masks from scalar enclosures.")


def main():
    manifest = read(ROOT / "manifest.json")
    for name, sha in manifest["sha256"].items():
        check(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha, "digest differs " + name)
    verify_thermal()
    for folder, function, filename in manifest["scorers"]:
        task = ROOT / folder
        spec = importlib.util.spec_from_file_location("score_" + folder[:3], task / "score.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        actual = getattr(module, function)()
        reference = read(task / filename)
        check(actual == reference, "score differs " + folder)
        print("Matched all recorded score fields for " + folder)


if __name__ == "__main__":
    main()
