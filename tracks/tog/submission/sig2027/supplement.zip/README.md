# Numerical evidence for the ignition-preview study

Extract this archive into a fresh directory. Run `python -I -B verify.py` there using Python 3.10 or newer. Verification uses the standard library and completes offline.

**Whole-scene material labels (T86).** The six checkpoints represent two stroke orders and three query times on one reconstructed woodpile. For 1, 4 and 8 frames, the verifier reconstructs the global, support, uniform and weighted site masks from the saved site heat, graph heat enclosures, hot-carrier counts and weighted gas enclosures. It compares all 72 ordered ID lists with the frozen predictions. These inputs begin after the spatial enclosure calculation. Regenerating spatial bounds from source particles requires the external scene geometry. This archive excludes geometry, gas trajectories and scene appearance.

**Regional decisions (T87).** The saved shell membership and region-only predictions are independent inputs to the regional scorer. For each of 18 windows it verifies agreement with the full-scene masks restricted to the shell, then checks actual native ignition frames within the region. It compares against ordinary exact early-stop replay and an unchanged-label guess.

**Positive witnesses (T88).** The scorer checks archived residual-heat and graph-witness decisions against the same shell IDs and event windows. It verifies the cost and fallback summaries using the recorded timings. Re-scoring starts from the exported witnesses.

**Terminal scan (T89).** A second run for each stroke order saved two times for every native step. The scorer checks all 720 frames' event identities and discrete counts against the original traces. It recomputes paired full-step and terminal-prefix timings for the whole scene and the regional early-stop query. The simulation completed each step in these measurements.

AB and BA denote the two stroke orders. The complete material event traces contain 360 updates per take. Six eligibility files identify unlit, fuel-positive sites and their stored heat. Public capture receipts are projected to the fields needed by the scorers. SCORE.json files record the expected output. Runtimes are single-machine observations supplied as data. Re-scoring recomputes the reported timing summaries from these measurements. It does not time a new simulation. Repeated site-window queries share sites and simulated frames.
